(function(){
var timer = setInterval(function(){
	if( window.jQuery ){
		$(document).ready(function(){
			yy.start();
		});
		clearInterval(timer);
	}
},1000/12);

var yy = {};

yy.start = function(){
	yy.goodsImgTri();
}

yy.goodsImgTri = function(){
	var prop = {};
	prop.div = document.querySelector( '.aj-box-rank' );
	Effect2( prop );
}

function Effect2( prop ){
	if( this instanceof Effect2 ){
		this.prop = prop;
		this.div = prop.div;
		this.nav = c.ajax({obj:this.div,className:'aj-nav-one'});
		this.blocks = c.ajax({obj:this.div,className:'aj-imgs-wrap'});
		this.initial();
		this.event();
	}else{
		return new Effect2( prop );
	}
}
Effect2.prototype={
	initial : function(){
		this.bianhao();
		this.setMinHeight();
	},
	event : function(){
		var that = this;
		$( this.div ).on( 'mouseover', function(ev){
			var e = ev || window.event,
				target = e.target || e.srcElement;
				
			if( $(target).hasClass('aj-nav-one') ){
				that.navStyle( target );
			}
		});
	},
	navStyle : function( obj ){
		var index = this.whichNav( obj );
		if( $(this.nav[index]).hasClass('aj-select') ){
			return true;
		}
		this.showNav( index );
		this.showBlock( index );
	},
	showNav : function( index ){
		$( this.nav ).removeClass( 'aj-select' );
		$( this.nav[index] ).addClass( 'aj-select' );
	},
	showBlock : function( index ){
		$( this.blocks ).hide();
		$( this.blocks[index] ).show();
	},
	whichNav : function( obj ){
		var index;
		for( var i = 0; i<this.nav.length; i++ ){
			if( this.nav[i] === obj ){
				index = i;
				break;
			}
		}
		return index;
	},
	bianhao : function(){
		var that =this;
		$( this.blocks ).each(function(){
			that.sortBlockInside( this );
		});
	},
	sortBlockInside : function( obj ){
		var ones = c.ajax({obj:obj,className:'aj-one'}),
			index = 1,
			zhishi;
		$( ones ).each(function(){
			zhishi = c.ajax({obj:this,className:'aj-index'})[0];
			zhishi.innerHTML = index;
			index++;
		});
	},
	setMinHeight : function(){
		var blocks = this.blocks,
			arr = [],
			num;
		$( blocks ).each(function(){
			arr.push( c.ajax({obj:this,className:'aj-one'}).length );
		});
		num = arr.sort(function( a, b ){
			return a-b;
		}).pop();
		$( blocks[0].parentNode.parentNode ).css({minHeight:num*100+'px'});
	},
};

var c = {
	ajax : function( prop ){
		return $( prop.obj ).find( '.'+prop.className );
	},
}
})()