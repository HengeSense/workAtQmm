(function(){

window.onload = function(){
	yy.start();
	
}
$( document ).ready(function(){
	yy.start();
	
});

var yy = {};
yy.start = function(){
	console.clear();


/* 	var prop = {};
	prop.arr = [];
	prop.arr[0] = document.querySelectorAll( '.rightPanel' )[4];
	prop.arr[1] = document.querySelectorAll( '.rightPanel' )[5];

	fixed_right( prop ); */	
}


var prop = {};
prop.arr = [];
prop.arr[0] = document.querySelectorAll( '.rightPanel' )[4];
prop.arr[1] = document.querySelectorAll( '.rightPanel' )[5];

fixed_right( prop );
function fixed_right( prop ) {
	var addNum = prop.arr.length;
	
    if ($("#pagefooter").length > 0 && $(".rightPanel").length > 0) {
        var headerHeight = 181,		//??
			footerHeight = $("#pagefooter").height(),
			windowHeight = $(window).height(),
			bodyHeight = windowHeight - headerHeight - footerHeight,
			leftHeight = $(".left_side").height(),
			rightHeight = $(".right_side").height(),
			rightOffsetTop = $('.right_side').offset().top,
			fixedTop = 40;
		
		
		var isShow = false,
			isBuchong = false,
			fixedOffsetFromFooter = 0,
			fixedTotalHeight = 0,
			scrollHeight,
			footerTop;
			
		prop.arr.forEach(function( obj ){
			fixedTotalHeight += $( obj ).height() + parseInt( $( obj ).css('margin-bottom') );
		});
		
		$(window).on( 'resize', function(){
			for( var i = 0; i < prop.arr.length; i++ ){
				$( prop.arr[i] ).css({
					'left' : document.querySelector('.right_side').getBoundingClientRect().left
				});
			}
		});
        $(window).scroll(function () {
			if( scrollHeight === $( window ).scrollTop() ){//scroll x
				for( var i = 0; i < prop.arr.length; i++ ){
					$( prop.arr[i] ).css({
						'left' : document.querySelector('.right_side').getBoundingClientRect().left
					});
				}
				return true;
			}
			scrollHeight = $( window ).scrollTop(),
			footerTop = document.getElementById('pagefooter').getBoundingClientRect().top;
			fixedBottom = prop.arr[prop.arr.length-1].getBoundingClientRect().bottom;
			// var p = $(".g_g");
            if ( leftHeight > rightHeight ) {
                if ( scrollHeight >= rightHeight + rightOffsetTop ) {
					fixedOffsetFromFooter = footerTop - ( fixedTop + fixedTotalHeight );
					// fixedOffsetFromFooter = footerTop - fixedBottom;
					console.log( fixedOffsetFromFooter );
					fixedOffsetFromFooter = fixedOffsetFromFooter > 0 ? 0 : ( fixedOffsetFromFooter  );					
					
					if( !isShow || fixedOffsetFromFooter !== 0 ){
						
						var previousSiblingTotalHeight = 0;
						for( var i = 0; i < prop.arr.length; i++ ){
							
							$( prop.arr[i] ).css({
								'position' : 'fixed',
								'top' : fixedTop + previousSiblingTotalHeight + fixedOffsetFromFooter,
								'left' : document.querySelector('.right_side').getBoundingClientRect().left
							});
							previousSiblingTotalHeight += $( prop.arr[i] ).height() + parseInt($( prop.arr[i] ).css('margin-bottom'));
						}
						//add height to right_side
						if( !isBuchong ){
							//$( prop.arr[0] ).before( "<div class='aj-buchong-height' style='width:100%;height:"+fixedTotalHeight+"px'></div>" );
							isBuchong = true;
						}
						isShow = true;
					}
                } else {
					if( isShow ){
						if( isBuchong ){
							//$( '.aj-buchong-height' ).remove();
							isBuchong = false;
						}
						for( var i = 0; i < prop.arr.length; i++ ){
							$( prop.arr[i] ).css({
								'position' : 'static',
								'top' : '0px'
							});
						}
						isShow = false;
					}
                }
            }
        });
    }
}





})()